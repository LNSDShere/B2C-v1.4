#!/usr/bin/env python3
"""DeadEnd Studio -- the button-driven IDE for the DeadEnd language.

A tiny local web server (Python stdlib only) that serves an editor in your
browser. Everything is buttons: write English, press Run, press Build.

  dec studio                     start Studio (opens your browser)
  dec studio --port 9000         pick a port
  dec studio --no-browser        do not auto-open the browser
  dec studio --workspace DIR     where your programs are saved
  dec studio game.dep            start Studio with that file open
"""
import os
import re
import sys
import json
import time
import uuid
import shutil
import socket
import zipfile
import platform
import threading
import subprocess
import webbrowser
import http.server
from urllib.parse import parse_qs, urlsplit, quote

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
LIB = os.path.join(ROOT, "lib")
VENDOR_RAYLIB = os.path.join(ROOT, "vendor", "raylib")
UI_DIR = os.path.join(SRC, "studio_ui")
sys.path.insert(0, SRC)

try:
    import dec as _dec
    VERSION = _dec.VERSION
except Exception:
    VERSION = "1.4.0"

# Dev/sandbox conveniences (existence-checked; absent on normal installs).
SANDBOX_SYSROOT = "/home/z/my-project/vendor-deb/sysroot"
SANDBOX_RAYLIB = "/home/z/my-project/raylib-build"
SANDBOX_MINGW = "/home/z/my-project/vendor-deb/mingw64"
SANDBOX_RAYLIB_WIN = "/home/z/my-project/raylib-win64"

MEDIA_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".wav", ".ogg", ".mp3"}
EXAMPLE_DESC = {
    "hello": "Your first program -- one line of English.",
    "guess": "A number-guessing chat game (it talks back).",
    "fizzbuzz": "The classic interview puzzle, in plain English.",
    "fibonacci": "Recursive numbers at full C speed.",
    "benchmark": "Count to a billion -- watch it fly.",
    "pong": "The arcade classic, with sounds.",
    "sketch": "Draw with the mouse.",
    "todo": "A to-do list that survives restarts.",
    "flappy": "The complete Flappy Bird game.",
    "flappy-art": "Flappy Bird with real pictures.",
}
DOC_PAGES = [
    ("readme", "Read Me First"),
    ("language", "The Language"),
    ("game-kit", "2D Game Kit"),
    ("app-kit", "App Kit (widgets)"),
    ("flappy-bird", "Build Flappy Bird"),
    ("studio", "DeadEnd Studio"),
]

STATE = {
    "ws": None,          # workspace dir
    "host": "127.0.0.1",
    "port": 8765,
    "preview": False,
    "sessions": {},      # sid -> Session
    "downloads": {},     # token -> {"path","name"}
    "disp_counter": 70,
    "lock": threading.Lock(),
}

IS_WINDOWS = platform.system() == "Windows"


class StudioError(Exception):
    pass


# ---------------------------------------------------------------- helpers --

def safe_name(name, default="program"):
    name = (name or "").strip().replace("/", "-").replace("\\", "-")
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9 _().-]*$", name):
        name = default
    name = name[:60]
    if not name.lower().endswith(".dep"):
        name += ".dep"
    return name


def strip_comments(src):
    out = []
    for ln in src.splitlines():
        s = ln.lstrip()
        out.append("" if s.startswith("#") else ln)
    return "\n".join(out)


def program_kind(src):
    low = strip_comments(src).lower()
    if re.search(r"\buse\s+game\s+kit\b", low):
        return "game"
    if re.search(r"\buse\s+app\s+kit\b", low):
        return "app"
    return "console"


def game_size(src):
    m = re.search(r"make\s+game\b[^\n]*?width\s+(\d+)\s+and\s+height\s+(\d+)",
                  strip_comments(src), re.I)
    w = int(m.group(1)) if m else 480
    h = int(m.group(2)) if m else 640
    return (min(max(w, 240), 1800), min(max(h, 240), 1200))


def collect_assets(src, bases):
    """Map relpath -> abs source for media files the program refers to."""
    found = {}
    for m in re.finditer(r'"([^"\n]{1,200})"', strip_comments(src)):
        rel = os.path.normpath(m.group(1).strip())
        if not rel or rel.startswith((".", "/", "\\")) or ".." in rel:
            continue
        if os.path.splitext(rel)[1].lower() not in MEDIA_EXT:
            continue
        for base in bases:
            p = os.path.join(base, rel)
            if os.path.isfile(p):
                found[rel] = p
                break
    return found


def tool_env():
    """Env additions so dec can build in dev sandboxes."""
    env = {}
    if not env.get("DEP_SYSROOT") and os.path.isdir(
            os.path.join(SANDBOX_SYSROOT, "usr", "include", "X11")):
        env["DEP_SYSROOT"] = SANDBOX_SYSROOT
    if not os.environ.get("DEP_RAYLIB_BUILD") and os.path.isfile(
            os.path.join(SANDBOX_RAYLIB, "libraylib.a")):
        env["DEP_RAYLIB_BUILD"] = SANDBOX_RAYLIB
    return env


def find_mingw():
    """Return (bin_dir, gcc, ar) for a Windows cross toolchain, or None."""
    cands = []
    env_dir = os.environ.get("DEP_MINGW")
    if env_dir:
        cands.append(os.path.join(env_dir, "usr", "bin"))
        cands.append(os.path.join(env_dir, "bin"))
    cands.append(os.path.join(SANDBOX_MINGW, "usr", "bin"))
    which = shutil.which("x86_64-w64-mingw32-gcc")
    if which:
        cands.append(os.path.dirname(which))
    for b in cands:
        gcc = os.path.join(b, "x86_64-w64-mingw32-gcc")
        if not os.path.isfile(gcc):
            # unversioned name may be a broken alternative; try -win32/-posix
            for suf in ("-win32", "-posix"):
                if os.path.isfile(gcc + suf):
                    os.symlink(gcc + suf, gcc) if not os.path.exists(gcc) else None
                    break
        if os.path.isfile(gcc):
            ar = os.path.join(b, "x86_64-w64-mingw32-ar")
            if not os.path.isfile(ar):
                ar = None
            return (b, gcc, ar)
    return None


def raylib_win64(mingw):
    """Path to a win64 libraylib.a (building it once if we can)."""
    cands = [os.environ.get("DEP_RAYLIB_WIN64") or "",
             SANDBOX_RAYLIB_WIN,
             os.path.join(os.path.expanduser("~"), ".cache", "dec",
                          "studio", "raylib-win64")]
    for c in cands:
        if c and os.path.isfile(os.path.join(c, "libraylib.a")):
            return os.path.join(c, "libraylib.a")
    # build it once (a couple of minutes, only ever once)
    target = cands[-1]
    try:
        os.makedirs(target, exist_ok=True)
        bin_dir, cc, _ = mingw
        env = dict(os.environ)
        env["PATH"] = bin_dir + os.pathsep + env.get("PATH", "")
        base = ["-O2", "-DPLATFORM_DESKTOP", "-DGRAPHICS_API_OPENGL_33",
                "-I" + VENDOR_RAYLIB, "-I" +
                os.path.join(VENDOR_RAYLIB, "external", "glfw", "include"), "-w"]
        objs = []
        for f in ("rcore", "rglfw", "rshapes", "rtextures", "rtext",
                  "rmodels", "raudio", "utils"):
            o = os.path.join(target, f + ".o")
            if not os.path.isfile(o):
                r = subprocess.run([cc] + base + ["-c", os.path.join(VENDOR_RAYLIB, f + ".c"), "-o", o],
                                   capture_output=True, env=env)
                if r.returncode != 0:
                    raise StudioError("raylib win64 build failed: " +
                                      r.stderr.decode("utf-8", "replace")[:400])
            objs.append(o)
        ar = mingw[2] or "ar"
        subprocess.run([ar, "rcs", os.path.join(target, "libraylib.a")] + objs,
                       check=True, env=env)
        return os.path.join(target, "libraylib.a")
    except Exception as e:
        raise StudioError("could not prepare raylib for Windows: %s" % e)


def emit_c(src_text):
    """Transpile DeadEnd source to C. Returns (c_code, uses_kits)."""
    from dep_parse import DepError, parse
    from dep_emit import Compiler
    try:
        comp = Compiler(parse(src_text))
        return comp.compile(), bool(comp.kit)
    except DepError as e:
        raise StudioError(str(e))
    except Exception as e:  # transpiler crash -- still English, still friendly
        raise StudioError("internal compiler error: %r" % (e,))


# ------------------------------------------------------------- compiling --

def build_native(dep_path, out_path):
    cmd = [sys.executable, os.path.join(SRC, "dec.py"),
           "build", dep_path, "-o", out_path]
    env = dict(os.environ)
    env.update(tool_env())
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900,
                           env=env)
    except subprocess.TimeoutExpired:
        return False, "compile timed out"
    log = (r.stdout or "") + (r.stderr or "")
    ok = r.returncode == 0 and os.path.isfile(out_path)
    return ok, log


def build_windows(src_text, out_path):
    """Cross-compile the editor's source into a real Windows .exe."""
    mingw = find_mingw()
    if not mingw:
        return False, ("No Windows compiler here. On this machine use "
                       "'This PC' instead, or install mingw-w64 "
                       "(sudo apt install gcc-mingw-w64-x86-64)."), []
    bin_dir, cc, _ = mingw
    c_code, kits = emit_c(src_text)
    tmp_dir = os.path.join(STATE["ws"], ".studio", "tmp")
    os.makedirs(tmp_dir, exist_ok=True)
    tmp = os.path.join(tmp_dir, uuid.uuid4().hex[:10] + ".c")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(c_code)
    env = dict(os.environ)
    env["PATH"] = bin_dir + os.pathsep + env.get("PATH", "")
    cmd = [cc, "-O2", "-w", "-I", LIB, "-I", VENDOR_RAYLIB,
           "-o", out_path, tmp, os.path.join(LIB, "dep_runtime.c")]
    if kits:
        cmd += ["-mwindows",
                os.path.join(LIB, "gamekit.c"),
                os.path.join(LIB, "appkit.c"),
                raylib_win64(mingw),
                "-lopengl32", "-lgdi32", "-lwinmm"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900,
                           env=env)
    except subprocess.TimeoutExpired:
        return False, "compile timed out", []
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    if r.returncode != 0:
        return False, (r.stderr or "compile failed")[:4000], []
    assets = collect_assets(src_text, [STATE["ws"], ROOT])
    return True, "", list(assets.items())


# -------------------------------------------------------------- sessions --

class Session(threading.Thread):
    def __init__(self, kind, exe, rundir, camera=None, display=None, env=None):
        super().__init__(daemon=True)
        self.sid = uuid.uuid4().hex[:10]
        self.kind = kind               # "console" | "game" | "app"
        self.rundir = rundir
        self.display = display
        self.camera = camera           # (screen_w, screen_h) or None
        self.buf = []
        self.lock = threading.Lock()
        self.shots = []                # shot indexes taken so far
        self.xvfb = None
        self.stopped = False
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if IS_WINDOWS else 0
        self.proc = subprocess.Popen(
            [exe], cwd=rundir,
            stdin=subprocess.PIPE if kind == "console" else subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env or None, creationflags=flags)

    # -- lifecycle ----------------------------------------------------------
    def run(self):
        if self.camera:
            print("[studio] cam session %s display=%s camera=%s" %
                  (self.sid, self.display, self.camera), flush=True)
            threading.Thread(target=self._cam, daemon=True).start()
        fd = self.proc.stdout.fileno()
        try:
            while True:
                chunk = os.read(fd, 4096)
                if not chunk:
                    break
                with self.lock:
                    self.buf.append(chunk.decode("utf-8", "replace"))
        except Exception:
            pass
        self.proc.wait()
        if self.xvfb:
            try:
                self.xvfb.terminate()
            except Exception:
                pass

    def _cam(self):
        w, h = self.camera
        for delay, idx in ((1.0, 1), (1.4, 2), (2.4, 3)):
            time.sleep(delay)
            print("[studio] cam tick %d: proc=%s" %
                  (idx, self.proc.poll()), flush=True)
            if self.proc.poll() is not None:
                return
            self._shot(idx)
        time.sleep(2.5)
        if self.proc.poll() is None:
            self.stopped = True
            self.proc.kill()

    def _shot(self, idx):
        try:
            w, h = self.camera
            raw = os.path.join(self.rundir, "raw%d.png" % idx)
            r = subprocess.run(
                ["ffmpeg", "-y", "-loglevel", "error", "-f", "x11grab",
                 "-video_size", "%dx%d" % (w, h), "-i", self.display,
                 "-frames:v", "1", raw], capture_output=True, timeout=30,
                env=dict(os.environ, DISPLAY=self.display))
            if r.returncode != 0 or not os.path.isfile(raw):
                self._diag(idx, b"rc=%d stderr=%s" %
                           (r.returncode, r.stderr or b"(none)"))
                return
            out = os.path.join(self.rundir, "shot%d.png" % idx)
            try:
                from PIL import Image
                im = Image.open(raw).convert("RGB")
                box = im.point(lambda p: 255 if p > 18 else 0).getbbox()
                if box and (box[2] - box[0]) * (box[3] - box[1]) > im.size[0] * im.size[1] * 0.12:
                    im = im.crop(box)
                im.save(out)
            except Exception:
                shutil.move(raw, out)
            with self.lock:
                self.shots.append(idx)
        except Exception as e:
            self._diag(idx, ("exc=%r" % (e,)).encode())

    def _diag(self, idx, msg):
        try:
            import traceback
            with open(os.path.join(self.rundir, "shotdiag%d.txt" % idx),
                      "wb") as f:
                f.write(msg)
                f.write(b"\n")
                f.write(traceback.format_exc().encode())
        except Exception:
            pass

    # -- api ----------------------------------------------------------------
    def output(self):
        with self.lock:
            return "".join(self.buf)

    def send_input(self, text):
        try:
            self.proc.stdin.write((text + "\n").encode())
            self.proc.stdin.flush()
        except Exception:
            pass

    def stop(self):
        self.stopped = True
        try:
            self.proc.kill()
        except Exception:
            pass
        if self.xvfb:
            try:
                self.xvfb.terminate()
            except Exception:
                pass

    def status(self):
        rc = self.proc.poll()
        return {"sid": self.sid, "kind": self.kind, "alive": rc is None,
                "exit_code": rc, "out": self.output()[-100000:],
                "shots": ["/api/shot/%s/%d" % (self.sid, i) for i in self.shots],
                "camera": bool(self.camera)}



def start_session(ws, content, name_hint, asset_base=None):
    kind = program_kind(content)
    sid_dir = os.path.join(ws, ".studio", "runs")
    os.makedirs(sid_dir, exist_ok=True)
    # lazy cleanup of runs older than 30 minutes
    now = time.time()
    for d in os.listdir(sid_dir):
        p = os.path.join(sid_dir, d)
        try:
            if os.path.isdir(p) and now - os.path.getmtime(p) > 1800:
                shutil.rmtree(p, ignore_errors=True)
        except OSError:
            pass
    rundir = tempfile_session(sid_dir)
    dep = os.path.join(rundir, "program.dep")
    with open(dep, "w", encoding="utf-8") as f:
        f.write(content)
    bases = [ws, ROOT]
    if asset_base and not STATE["preview"] and os.path.isdir(asset_base):
        bases.append(asset_base)
    for rel, src in collect_assets(content, bases).items():
        dst = os.path.join(rundir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
    exe = os.path.join(rundir, "program" + (".exe" if IS_WINDOWS else ""))
    ok, log = build_native(dep, exe)
    if not ok:
        shutil.rmtree(rundir, ignore_errors=True)
        return {"ok": False, "error": clean_log(log)}

    camera = None
    display = None
    xvfb = None
    env = None
    graphical = kind in ("game", "app")
    if graphical and STATE["preview"] and shutil.which("ffmpeg") \
            and shutil.which("Xvfb"):
        gw, gh = game_size(content) if kind == "game" else (420, 500)
        sw, sh = gw + 80, gh + 80
        display = grab_display()
        if display:
            xvfb = subprocess.Popen(
                ["Xvfb", display, "-screen", "0", "%dx%dx24" % (sw, sh)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(0.6)
            if xvfb.poll() is None:
                camera = (sw, sh)
                env = dict(os.environ, DISPLAY=display)
            else:
                display = None
    s = Session(kind, exe, rundir, camera=camera, display=display, env=env)
    if camera:
        s.xvfb = xvfb
    with STATE["lock"]:
        STATE["sessions"][s.sid] = s
    s.start()
    return {"ok": True, "kind": kind, "sid": s.sid,
            "camera": bool(camera), "preview": STATE["preview"]}


def tempfile_session(parent):
    d = os.path.join(parent, uuid.uuid4().hex[:10])
    os.makedirs(d, exist_ok=True)
    return d


def grab_display():
    """A display number nothing is using (probed, not assumed)."""
    with STATE["lock"]:
        start = STATE["disp_counter"]
        STATE["disp_counter"] = 71 if start >= 99 else start + 1
    order = list(range(start, 100)) + list(range(70, start))
    for n in order:
        sock = "/tmp/.X11-unix/X%d" % n
        if not os.path.exists(sock):
            return ":%d" % n
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.settimeout(0.2)
            s.connect(sock)
            s.close()
            continue                      # a live server has it
        except OSError:
            return ":%d" % n              # stale socket file -> reusable
    return None                           # everything busy: no camera


def clean_log(log):
    log = log.replace("program.dep: error:", "error:")
    log = re.sub(r"^dec: ", "", log, flags=re.M)
    return log.strip()


def error_line(log):
    m = re.search(r"line (\d+)", log)
    return int(m.group(1)) if m else None


# ------------------------------------------------------- tiny markdown ----

def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def inline(s):
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"<a href='\2'>\1</a>", s)
    return s


def md_to_html(text):
    out, code, table = [], False, []
    fenced = "```"
    for ln in text.splitlines():
        if ln.startswith(fenced):
            if code:
                out.append("</pre>")
                code = False
            else:
                out.append("<pre>")
                code = True
            continue
        if code:
            out.append(esc(ln))
            continue
        if ln.strip().startswith("|") and ln.strip().endswith("|"):
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            if all(re.fullmatch(r":?-+:?", c) for c in cells):
                continue
            table.append(cells)
            continue
        if table:
            out.append("<table>" + "".join(
                "<tr>" + "".join("<td>%s</td>" % inline(esc(c)) for c in row)
                + "</tr>" for row in table) + "</table>")
            table = []
        h = re.match(r"(#{1,4})\s+(.*)", ln)
        if h:
            lvl = len(h.group(1)) + 1
            out.append("<h%d>%s</h%d>" % (lvl, inline(esc(h.group(2))), lvl))
            continue
        if ln.strip().startswith(("- ", "* ")):
            out.append("<li>%s</li>" % inline(esc(ln.strip()[2:])))
            continue
        if not ln.strip():
            out.append("")
            continue
        out.append("<p>%s</p>" % inline(esc(ln)))
    if table:
        out.append("<table>" + "".join(
            "<tr>" + "".join("<td>%s</td>" % inline(esc(c)) for c in row)
            + "</tr>" for row in table) + "</table>")
    body = "\n".join(out)
    # example links become "open raw" links
    body = body.replace("href='..", "href='/api/raw?path=..")
    body = re.sub(r"href='([^':]*\.md)'", r"href='/docs?page=\1'", body)
    body = body.replace("href='docs/", "href='/docs?page=")
    return body


def doc_page(page):
    files = {"readme": os.path.join(ROOT, "README.md"),
             "studio": os.path.join(ROOT, "docs", "studio.md")}
    p = files.get(page) or os.path.join(ROOT, "docs", page + ".md")
    if not os.path.isfile(p):
        return None
    with open(p, encoding="utf-8") as f:
        return f.read()


# ------------------------------------------------------------- web server --

MIME = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8", ".svg": "image/svg+xml",
        ".png": "image/png", ".md": "text/plain; charset=utf-8",
        ".dep": "text/plain; charset=utf-8", ".wav": "audio/wav",
        ".ogg": "audio/ogg", ".mp3": "audio/mpeg", ".jpg": "image/jpeg",
        ".zip": "application/zip", ".exe": "application/octet-stream"}

DOCS_SHELL = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DeadEnd docs</title>
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/style.css">
</head>
<body class="docs-body">
<div class="docs-wrap">
<aside class="docs-nav">
  <a class="docs-brand" href="/">Back to Studio</a>
  %(nav)s
</aside>
<main class="docs-main">%(body)s</main>
</div>
</body></html>"""


def open_folder(path):
    try:
        if platform.system() == "Windows":
            os.startfile(path)  # type: ignore[attr-defined]
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def launch_tour():
    py = sys.executable
    # under pythonw (no console) the tour would be invisible -- use python.exe
    if py.lower().endswith("pythonw.exe"):
        alt = py[:-len("pythonw.exe")] + "python.exe"
        if os.path.isfile(alt):
            py = alt
    dec_cmd = [py, os.path.join(SRC, "dec.py"), "tour"]
    try:
        if platform.system() == "Windows":
            subprocess.Popen(["cmd", "/k"] + dec_cmd,
                             creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
            return True
        for term, flag in (("x-terminal-emulator", ["-e"]),
                           ("gnome-terminal", ["--"]),
                           ("konsole", ["-e"]),
                           ("xfce4-terminal", ["-x"]),
                           ("xterm", ["-e"])):
            if shutil.which(term):
                subprocess.Popen([term] + flag + dec_cmd)
                return True
    except Exception:
        pass
    return False


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "DeadEndStudio/" + VERSION

    def log_message(self, fmt, *args):
        pass

    # ---- plumbing ---------------------------------------------------------
    def jsend(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        try:
            return json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            return {}

    def file_send(self, path, mime, download_name=None):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            self.jsend({"error": "not found"}, 404)
            return
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        if download_name:
            self.send_header("Content-Disposition",
                             'attachment; filename="%s"' % download_name)
        self.end_headers()
        self.wfile.write(data)

    def stop_all_sessions(self):
        with STATE["lock"]:
            sessions = list(STATE["sessions"].values())
        for s in sessions:
            s.stop()

    # ---- GET --------------------------------------------------------------
    def do_GET(self):
        path = urlsplit(self.path).path
        if path in ("/", "/index.html"):
            self.file_send(os.path.join(UI_DIR, "index.html"), MIME[".html"])
            return
        if path in ("/style.css", "/app.js", "/favicon.svg"):
            ext = os.path.splitext(path)[1]
            self.file_send(os.path.join(UI_DIR, os.path.basename(path)), MIME[ext])
            return
        if path == "/docs":
            self.docs_page()
            return
        if path == "/api/info":
            self.api_info()
            return
        m = re.match(r"^/api/shot/([a-f0-9]+)/([0-9]+)$", path)
        if m:
            s = STATE["sessions"].get(m.group(1))
            p = os.path.join(s.rundir, "shot%s.png" % m.group(2)) if s else ""
            self.file_send(p, MIME[".png"])
            return
        m = re.match(r"^/api/download/([a-f0-9]+)$", path)
        if m:
            d = STATE["downloads"].get(m.group(1))
            if not d:
                self.jsend({"error": "expired"}, 404)
                return
            self.file_send(d["path"], MIME.get(os.path.splitext(d["path"])[1],
                                                "application/octet-stream"),
                           d["name"])
            return
        if path == "/api/raw":
            self.api_raw()
            return
        self.jsend({"error": "not found"}, 404)

    # ---- POST -------------------------------------------------------------
    def do_POST(self):
        path = urlsplit(self.path).path
        routes = {
            "/api/new": self.api_new, "/api/open": self.api_open,
            "/api/example": self.api_example, "/api/save": self.api_save,
            "/api/run": self.api_run, "/api/poll": self.api_poll,
            "/api/input": self.api_input, "/api/stop": self.api_stop,
            "/api/build": self.api_build, "/api/doctor": self.api_doctor,
            "/api/openfolder": self.api_openfolder, "/api/tour": self.api_tour,
            "/api/quit": self.api_quit,
        }
        fn = routes.get(path)
        if not fn:
            self.jsend({"error": "not found"}, 404)
            return
        try:
            fn(self.body())
        except StudioError as e:
            self.jsend({"ok": False, "error": str(e),
                        "line": error_line(str(e))})
        except Exception as e:
            self.jsend({"ok": False, "error": "studio hiccup: %r" % (e,)})

    # ---- endpoints --------------------------------------------------------
    def api_info(self):
        ws = STATE["ws"]
        files = []
        try:
            for f in sorted(os.listdir(ws)):
                if f.endswith(".dep"):
                    p = os.path.join(ws, f)
                    files.append({"name": f, "size": os.path.getsize(p),
                                  "mtime": int(os.path.getmtime(p))})
        except OSError:
            pass
        examples = []
        exdir = os.path.join(ROOT, "examples")
        for f in sorted(os.listdir(exdir)):
            if f.endswith(".dep"):
                examples.append({"name": f[:-4], "title": f[:-4],
                                 "desc": EXAMPLE_DESC.get(f[:-4], "")})
        for i in range(1, 7):
            rel = "flappy-steps/step-%d" % i
            if os.path.isfile(os.path.join(exdir, rel + ".dep")):
                examples.append({"name": rel, "title": "flappy, step %d" % i,
                                 "desc": "Tutorial step %d of 6" % i})
        sysname = platform.system()
        self.jsend({
            "version": VERSION, "workspace": ws, "files": files,
            "examples": examples,
            "docs": [{"page": p, "title": t} for p, t in DOC_PAGES],
            "preview": STATE["preview"],
            "can_windows": bool(find_mingw()) or sysname == "Windows",
            "native_label": {"Windows": "Windows", "Darwin": "macOS"}.get(sysname, sysname),
            "can_tour": sysname == "Windows" or bool(os.environ.get("DISPLAY")),
        })

    def api_new(self, b):
        name = safe_name(b.get("name"), "program")
        ws = STATE["ws"]
        n = 1
        while os.path.exists(os.path.join(ws, name)):
            n += 1
            base, ext = name[:-4], name[-4:]
            name = "%s-%d%s" % (base, n, ext)
        self.jsend({"ok": True, "name": name})

    def api_open(self, b):
        # -- open any .dep file on this computer (desktop Studio; used by
        #    the Windows "double-click a .dep file" file association)
        if b.get("path") and not STATE["preview"]:
            p = os.path.abspath(b["path"])
            if not p.lower().endswith(".dep"):
                self.jsend({"ok": False, "error": "that is not a DeadEnd program file (.dep)"})
                return
            try:
                if not os.path.isfile(p):
                    raise StudioError("no file at " + p)
                if os.path.getsize(p) > 5_000_000:
                    raise StudioError("that file is too big to open here")
                with open(p, encoding="utf-8") as f:
                    content = f.read()
            except OSError as e:
                self.jsend({"ok": False, "error": "could not read it: %s" % e})
                return
            except StudioError as e:
                self.jsend({"ok": False, "error": str(e)})
                return
            self.jsend({"ok": True, "name": os.path.basename(p),
                        "content": content, "path": p})
            return
        name = safe_name(b.get("name"))
        p = os.path.join(STATE["ws"], name)
        if not os.path.isfile(p):
            self.jsend({"ok": False, "error": "no program called " + name})
            return
        with open(p, encoding="utf-8") as f:
            self.jsend({"ok": True, "name": name, "content": f.read()})

    def api_example(self, b):
        rel = (b.get("name") or "").replace("\\", "/")
        if ".." in rel or rel.startswith("/"):
            self.jsend({"ok": False, "error": "no such example"})
            return
        p = os.path.join(ROOT, "examples", rel + ".dep")
        if not os.path.isfile(p):
            self.jsend({"ok": False, "error": "no such example"})
            return
        with open(p, encoding="utf-8") as f:
            self.jsend({"ok": True, "name": os.path.basename(rel) + ".dep",
                        "content": f.read()})

    def api_save(self, b):
        # -- saving a file that was opened from disk: write it back there
        if b.get("path") and not STATE["preview"]:
            p = os.path.abspath(b["path"])
            if not p.lower().endswith(".dep"):
                self.jsend({"ok": False,
                            "error": "not a DeadEnd program file (.dep)"})
                return
            try:
                with open(p, "w", encoding="utf-8") as f:
                    f.write(b.get("content", ""))
            except OSError as e:
                self.jsend({"ok": False, "error": "could not save: %s" % e})
                return
            self.jsend({"ok": True, "name": os.path.basename(p), "path": p,
                        "size": os.path.getsize(p), "exists": True})
            return
        name = safe_name(b.get("name"))
        p = os.path.join(STATE["ws"], name)
        with open(p, "w", encoding="utf-8") as f:
            f.write(b.get("content", ""))
        self.jsend({"ok": True, "name": name,
                    "size": os.path.getsize(p), "exists": True})

    def api_run(self, b):
        content = b.get("content", "")
        if not content.strip():
            self.jsend({"ok": False, "error": "nothing to run -- write some code first"})
            return
        self.stop_all_sessions()
        r = start_session(STATE["ws"], content, b.get("name"),
                          asset_base=b.get("asset_base"))
        if not r.get("ok"):
            r["line"] = error_line(r.get("error", ""))
        self.jsend(r)

    def api_poll(self, b):
        s = STATE["sessions"].get(b.get("sid", ""))
        if not s:
            self.jsend({"ok": False, "error": "that run is gone"})
            return
        self.jsend(s.status())

    def api_input(self, b):
        s = STATE["sessions"].get(b.get("sid", ""))
        if s:
            s.send_input(b.get("text", ""))
        self.jsend({"ok": True})

    def api_stop(self, b):
        sid = b.get("sid")
        with STATE["lock"]:
            sessions = list(STATE["sessions"].values())
        for s in sessions:
            if not sid or s.sid == sid:
                s.stop()
        self.jsend({"ok": True})

    def api_build(self, b):
        ws = STATE["ws"]
        content = b.get("content", "")
        if not content.strip():
            self.jsend({"ok": False, "error": "nothing to build -- write some code first"})
            return
        target = b.get("target", "windows")
        base = safe_name(b.get("out_name") or b.get("name") or "my-program",
                         "my-program")[:-4]
        builds = os.path.join(ws, "builds")
        os.makedirs(builds, exist_ok=True)
        tmp_dir = os.path.join(ws, ".studio", "tmp")
        os.makedirs(tmp_dir, exist_ok=True)
        dep = os.path.join(tmp_dir, uuid.uuid4().hex[:10] + ".dep")
        with open(dep, "w", encoding="utf-8") as f:
            f.write(content)
        sysname = platform.system()
        assets = []
        asset_base = b.get("asset_base")
        if asset_base and (STATE["preview"] or not os.path.isdir(asset_base)):
            asset_base = None
        ab = [asset_base] if asset_base else []
        if target == "windows" and sysname != "Windows" and not find_mingw():
            self.jsend({"ok": False, "error":
                        "No Windows compiler on this machine. Build for "
                        "This PC instead, or install: sudo apt install "
                        "gcc-mingw-w64-x86-64"})
            return
        try:
            if target == "windows" and sysname == "Windows":
                exe_out = os.path.join(builds, base + ".exe")
                ok, log = build_native(dep, exe_out)
                assets = sorted(collect_assets(content, [ws, ROOT] + ab).items())
            elif target == "windows":
                exe_out = os.path.join(builds, base + ".exe")
                ok, log, assets = build_windows(content, exe_out)
            else:
                exe_out = os.path.join(builds, base +
                                       (".exe" if sysname == "Windows" else ""))
                ok, log = build_native(dep, exe_out)
                assets = sorted(collect_assets(content, [ws, ROOT] + ab).items())
        finally:
            try:
                os.remove(dep)
            except OSError:
                pass
        if not ok:
            self.jsend({"ok": False, "error": clean_log(log),
                        "line": error_line(log)})
            return
        note = ""
        out_path = exe_out
        if assets:
            out_path = os.path.join(builds, base + ".zip")
            with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(exe_out, os.path.basename(exe_out))
                for rel, src in assets:
                    z.write(src, rel)
            note = ("Bundled %d file(s) the program needs (pictures/sounds). "
                    "Unzip everything into one folder, then double-click "
                    "the exe." % len(assets))
        token = uuid.uuid4().hex[:12]
        STATE["downloads"][token] = {"path": out_path,
                                     "name": os.path.basename(out_path)}
        self.jsend({"ok": True, "filename": os.path.basename(out_path),
                    "size": os.path.getsize(out_path),
                    "download_url": "/api/download/" + token,
                    "path": out_path, "note": note,
                    "assets": [a for a, _ in assets],
                    "windows": target == "windows",
                    "folder": builds})

    def api_doctor(self, b):
        env = dict(os.environ)
        env.update(tool_env())
        r = subprocess.run([sys.executable, os.path.join(SRC, "dec.py"),
                            "doctor"], capture_output=True, text=True,
                           timeout=300, env=env)
        self.jsend({"ok": r.returncode == 0,
                    "text": (r.stdout + r.stderr).strip()})

    def api_openfolder(self, b):
        if STATE["preview"]:
            self.jsend({"ok": False, "error": "not in the online preview"})
            return
        self.jsend({"ok": open_folder(b.get("path") or STATE["ws"])})

    def api_tour(self, b):
        if STATE["preview"]:
            self.jsend({"ok": False, "error": "not in the online preview"})
            return
        self.jsend({"ok": launch_tour()})

    def api_quit(self, b):
        """Graceful shutdown -- the installer/uninstaller ask for this
        through the launcher before replacing files."""
        self.jsend({"ok": True})
        httpd = STATE.get("httpd")
        if httpd:
            threading.Timer(0.4, httpd.shutdown).start()

    def api_raw(self):
        qs = parse_qs(urlsplit(self.path).query)
        rel = (qs.get("path") or [""])[0].replace("\\", "/")
        norm = os.path.normpath(rel)
        if norm.startswith("..") or os.path.isabs(norm):
            self.jsend({"error": "nope"}, 403)
            return
        p = os.path.join(ROOT, norm)
        ext = os.path.splitext(p)[1].lower()
        if not os.path.isfile(p) or ext not in MIME:
            self.jsend({"error": "not found"}, 404)
            return
        self.file_send(p, MIME[ext])

    def docs_page(self):
        qs = parse_qs(urlsplit(self.path).query)
        page = (qs.get("page") or ["language"])[0]
        md = doc_page(page)
        if md is None:
            page, md = "language", doc_page("language")
        nav = "".join('<a class="%s" href="/docs?page=%s">%s</a>' %
                      ("on" if p == page else "", p, t) for p, t in DOC_PAGES)
        html = DOCS_SHELL % {"nav": nav, "body": md_to_html(md)}
        data = html.encode()
        self.send_response(200)
        self.send_header("Content-Type", MIME[".html"])
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


# ------------------------------------------------------------------ main --

def default_workspace():
    home = os.path.expanduser("~")
    if platform.system() == "Windows":
        docs = os.path.join(home, "Documents")
        base = os.path.join(docs if os.path.isdir(docs) else home,
                            "DeadEnd Programs")
    else:
        base = os.path.join(home, "DeadEnd Programs")
    try:
        os.makedirs(base, exist_ok=True)
        return base
    except OSError:
        base = os.path.join(home, "deadend-programs")
        os.makedirs(base, exist_ok=True)
        return base


def server_info_path():
    """Where the running Studio server writes its port+pid.
    The Windows launcher ("DeadEnd Studio.exe") reads this to avoid
    starting a second copy when you double-click a .dep file."""
    if IS_WINDOWS:
        base = os.path.join(os.environ.get("LOCALAPPDATA",
                                           os.path.expanduser("~")), "DeadEnd")
    else:
        base = os.path.expanduser("~/.local/share/deadend")
    try:
        os.makedirs(base, exist_ok=True)
        return os.path.join(base, "server.json")
    except OSError:
        return None


def main(argv):
    host, port, ws = "127.0.0.1", 8765, None
    no_browser, port_given = False, False
    launch_file = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--port" and i + 1 < len(argv):
            port, port_given, i = int(argv[i + 1]), True, i + 2
        elif a == "--host" and i + 1 < len(argv):
            host, i = argv[i + 1], i + 2
        elif a == "--workspace" and i + 1 < len(argv):
            ws, i = argv[i + 1], i + 2
        elif a == "--launch" and i + 1 < len(argv):
            launch_file, i = argv[i + 1], i + 2
        elif a.startswith("--launch="):
            launch_file, i = a[len("--launch="):], i + 1
        elif a == "--no-browser":
            no_browser, i = True, i + 1
        elif not a.startswith("-") and a.lower().endswith(".dep") \
                and launch_file is None:
            launch_file, i = a, i + 1
        else:
            i += 1
    STATE["ws"] = ws or default_workspace()
    os.makedirs(os.path.join(STATE["ws"], "builds"), exist_ok=True)
    STATE["preview"] = host not in ("127.0.0.1", "localhost", "::1")
    if launch_file:
        launch_file = os.path.abspath(launch_file)
        if not os.path.isfile(launch_file):
            print("Studio: file not found: %s" % launch_file)
            launch_file = None

    server_cls = http.server.ThreadingHTTPServer
    httpd = None
    for attempt in range(21):
        try:
            httpd = server_cls((host, port), Handler)
            break
        except OSError:
            if port_given:
                print("Studio: port %d is busy -- pick another with "
                      "--port N" % port)
                return 1
            port += 1
    if httpd is None:
        print("Studio: could not find a free port.")
        return 1

    info_path = server_info_path()
    if info_path:
        try:
            with open(info_path, "w", encoding="utf-8") as f:
                json.dump({"port": port, "pid": os.getpid()}, f)
        except OSError:
            pass
    STATE["httpd"] = httpd

    shown_host = "127.0.0.1" if host == "0.0.0.0" else host
    url = "http://%s:%d/" % (shown_host, port)
    if launch_file:
        url += "?file=" + quote(launch_file)
    print("+" + "-" * 58 + "+")
    print("| DeadEnd Studio v%-41s |" % VERSION)
    print("| Programs are saved in: %-36s |" % (STATE["ws"][:36]))
    print("| %s |" % ("ONLINE PREVIEW MODE" if STATE["preview"]
                       else "Running privately on this computer").ljust(58))
    print("+" + "-" * 58 + "+")
    print("| Open this address in your browser:")
    print("|   %s" % url)
    print("| Keep this window open while you work. Ctrl+C stops Studio.")
    print("+" + "-" * 58 + "+", flush=True)

    sysname = platform.system()
    can_open = sysname == "Windows" or sysname == "Darwin" \
        or os.environ.get("DISPLAY")
    if no_browser or not can_open:
        print("(browser not opened automatically -- %s)" %
              ("disabled" if no_browser else "no display detected"), flush=True)
    else:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        for s in list(STATE["sessions"].values()):
            s.stop()
        if info_path:
            try:
                with open(info_path, encoding="utf-8") as f:
                    cur = json.load(f)
                if cur.get("pid") == os.getpid():
                    os.remove(info_path)
            except Exception:
                pass
        print("\nStudio stopped. Your programs live in: %s" % STATE["ws"])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
