/* ==========================================================================
 * DeadEnd App Dev Kit -- appkit.h
 * All DEPValue parameters are CONSUMED (the kit releases them).
 * ========================================================================== */
#ifndef DEP_APPKIT_H
#define DEP_APPKIT_H

#include "dep_runtime.h"

/* widget types */
enum {
    DEP_W_TITLE = 0, DEP_W_LABEL, DEP_W_BUTTON, DEP_W_FIELD,
    DEP_W_CHECKBOX, DEP_W_SLIDER, DEP_W_IMAGE, DEP_W_PANEL
};

void dep_app_setup(DEPValue title, double w, double h);
void dep_app_add(int type, const char *name, double x, double y, double w, double h);
void dep_app_on_click(const char *name, void (*fn)(void));
void dep_app_run(void);

/* reading widget values */
DEPStr  *dep_a_field(DEPValue name);      /* -> text  */
DEPStr  *dep_a_label(DEPValue name);      /* -> text  */
int      dep_a_checkbox(DEPValue name);   /* -> yes/no */
double   dep_a_slider(DEPValue name);     /* -> number 0..100 */

/* writing widget values */
void dep_app_set_text(const char *name, DEPValue text);
void dep_app_set_val(const char *name, DEPValue val);

/* ---- motion kit (v1.4.0): UI motion -- all DEPValue args are CONSUMED ---- */
void dep_ui_pop_in(const char *name, double dur, DEPValue feel);
void dep_ui_pop_out(const char *name, double dur, DEPValue feel);
void dep_ui_fade_in(const char *name, double dur, DEPValue feel);
void dep_ui_fade_out(const char *name, double dur, DEPValue feel);
void dep_ui_slide_in(const char *name, DEPValue dir, double dur, DEPValue feel);
void dep_ui_slide_out(const char *name, DEPValue dir, double dur, DEPValue feel);
void dep_ui_glide(const char *name, double x, double y, double dur, DEPValue feel);
void dep_ui_shake(const char *name, double strength);
void dep_ui_bump(const char *name);

#endif /* DEP_APPKIT_H */
