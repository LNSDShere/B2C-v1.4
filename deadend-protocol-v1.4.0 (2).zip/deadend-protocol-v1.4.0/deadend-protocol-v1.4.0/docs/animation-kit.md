# The Motion Kit

The motion kit (new in v1.4.0) adds animation to DeadEnd in plain English.
It is not a separate `use` line: once your program uses the game kit or the
app kit, every motion sentence just works. The engine runs at C speed, ticks
itself every frame, and drives your variables directly -- you animate a
number, the kit draws it.

```
move dot.x toward 300 lasting 1.5 seconds feeling bouncy
```

That one sentence animates `dot.x` from wherever it is now to 300 over one
and a half seconds, overshooting a little and settling like a cartoon. No
timers, no frame counting, no interpolation code.

## The four kinds of motion

1. **Tweens** (`move`) -- go from here to there along an easing curve.
2. **Springs** (`spring`) -- real physics: acceleration, velocity, wobble.
3. **Timelines** -- chain steps and play them as one named scene.
4. **Dressing** -- particles, screen shake, flash, fade, zoom, and widget
   animations for apps.

Every animation drives a **global variable** (a plain number, or a field of
a global map). That is the whole contract: the variable holds the truth, the
animation moves it, your drawing code just reads it.

```
use game kit

make game "Orbit" with width 400 and height 300

set dot to {x: 50, y: 150}

when game starts
  move dot.x toward 350 lasting 2 seconds feeling bouncy
end

every frame
  clear "night blue"
  circle dot.x, dot.y, 14, "gold"
end

run game
```

## move: tweens

```
move score toward 100
move dot.x toward 300 lasting 1.5 seconds
move dot toward {x: 300, y: 200} lasting 1.5 seconds feeling bouncy
move hp toward 50 waiting 0.5 seconds
move ghost.x toward mouse.x lasting 0.8 seconds feeling quick
```

- `toward` sets the destination. Without `lasting`, the move takes 1 second.
- `feeling <word>` picks the easing curve (the table is below).
- `lasting 1.5 seconds` -- also `milliseconds`/`ms`: `lasting 300 ms`.
- `waiting 0.5 seconds` -- delay before the move starts.
- `starting from 20` -- override where it starts from.
- `reversing` -- ping-pong: there and back.
- `repeating 3 times` -- repeat the whole cycle; `repeating forever`.
- Animate several fields at once with a map: `move dot toward {x: 100, y: 50}`
  moves `dot.x` and `dot.y` together (each field gets its own animation, so
  different `feeling` per field just means two sentences).

## spring: real physics

```
spring hp toward 50
spring ball.x toward mouse.x with speed 3 and wobble 4
spring arm.y toward 120 with stiffness 300 and damping 12
spring dot.y toward 80 lasting 2 seconds with wobble 6
```

A spring is a damped oscillator: it accelerates toward the target, overshoots,
and settles. Three ways to tune it:

- `with speed 2` -- scales responsiveness (stiffness = 170 * speed^2).
- `with wobble 6` -- how much it oscillates around the target (0 = dead
  beat, bigger = bouncier). Default wobble is 2.
- `with stiffness 300 and damping 12` -- the raw physics knobs, if you know
  what you want.
- `lasting 2 seconds` -- springs accept a duration too: it picks the speed
  so the spring settles in *about* that long (speed ~ 1/duration). When
  both are given, `with speed`/`with stiffness` win.

Defaults (no knobs): stiffness 170, damping 26 -- a quick, slightly springy
settle. A spring "finishes" when it stays within a hair of the target, so
`moving x` turns to `no` on its own.

## feeling: the 31 curves

Feeling words are plain English for easing curves:

| feeling | curve | character |
|---------|-------|-----------|
| `smooth` (default) | cubic in-out | the all-rounder |
| `gentle` | sine in-out | soft breathe |
| `soft` | sine out | eases out gently |
| `quick` | cubic out | fast start, glides in |
| `swift` | quad out | quick and light |
| `building` | cubic in | slow start, rushes the end |
| `accelerating` | quad in | gentle rush |
| `bouncy` | back out | overshoots, comes back |
| `springy` | elastic out | jiggles like jelly |
| `snappy` | back in-out | anticipates, then snaps |
| `dramatic` | bounce out | lands like a ball |

Or name any curve directly: `feeling "ease-out-bounce"`. The full family:
linear; quad/cubic/quart/quint/expo/circ/sine in, out and in-out; back,
elastic and bounce in, out and in-out. That is 31 curves -- all of them
available, none of them required.

You can also sample a curve directly in any expression:

```
set p to ease("bouncy", 0.5)       # the curve at 50%: 0.765625
```

## timelines: steps that play in order

```
make timeline "intro"
add move dot.y toward 80 lasting 1 second to timeline "intro"
add wait 0.5 seconds to timeline "intro"
add move dot.x toward 200 lasting 1 second to timeline "intro"
add pop in label "ready" lasting 0.4 seconds to timeline "intro"
play timeline "intro"
```

- Each step starts when the previous one finishes. `wait 0.5 seconds` is a
  pause between steps.
- Add `together` to a step to start it at the same moment as the previous
  step: `add move dot.x toward 0 lasting 1 second to timeline "intro" together`.
- `play timeline "intro"` -- also `play timeline "intro" repeating 3 times`
  and `repeating forever`.
- `pause timeline "intro"` / `resume timeline "intro"` / `stop timeline "intro"`.
- Questions: `if playing "intro" ...`, `if finished "intro" ...`.
- Declaring `make timeline "x"` again gives you a fresh, empty timeline with
  that name (so re-building a scene never duplicates steps).

## questions and stopping

```
if moving dot.x                 # is that target animating right now?
if moving dot                   # is anything on dot moving?
stop moving dot.x               # freeze it where it is
stop moving dot                 # freeze everything on dot
stop every animation            # the big red switch
```

`moving`, `playing` and `finished` are questions you can also use inline:
`print moving dot.x`.

## particles

```
burst 30 sparks at 200, 150 with color "gold" and speed 180 and size 3 and life 1.4
rain 80 with color "light blue" and speed 160 and size 2 and life 4
snow 60 with color "white" and speed 40 and size 2 and life 8
clear particles
print particles                  # how many are alive right now
```

- `burst <n> <kind> at x, y ...` -- an explosion. Kinds: `sparks`, `confetti`,
  `smoke`, `stars`, `fire`, `bubbles`, `hearts`, `particles`.
- `rain <n> ...` falls from the top of the screen; `snow <n> ...` drifts.
- Options: `color`, `speed` (pixels/second), `size` (pixels), `life` (seconds).
- In game programs they draw themselves; `clear particles` stops them all.

## screen effects

```
shake screen with strength 6 lasting 0.25 seconds
flash white lasting 0.1 seconds
fade to black lasting 0.8 seconds
fade from black lasting 1 second
zoom screen to 1.15 lasting 0.4 seconds feeling snappy
reset screen
```

Shake, flash, fade and zoom apply to the whole window (they ride the game
camera, so everything on screen moves together). `reset screen` snaps zoom
and fade back to normal instantly.

## app kit: widget animation

Every widget animation targets a widget by its name in quotes:

```
pop in button "Go" lasting 0.4 seconds feeling bouncy
pop out label "row3" lasting 0.3 seconds
fade in panel "card" lasting 0.5 seconds
slide in panel "menu" from "left" lasting 0.45 seconds feeling snappy
slide out panel "menu" to "right" lasting 0.35 seconds
glide label "coin" to 300, 200 lasting 0.8 seconds feeling springy
bump button "Go"
shake field "name" with strength 6
wiggle label "status" with strength 3
```

- `pop in`/`pop out` -- scale from 0 up (or down to nothing).
- `fade in`/`fade out` -- transparency.
- `slide in ... from "left"` -- from left/right/top/bottom;
  `slide out ... to "right"` back out again.
- `glide ... to x, y` -- float to a new position on the window.
- `bump` -- a quick scale-up-and-back, perfect for button clicks.
- `shake`/`wiggle ... with strength N` -- a horizontal no-no-no.
- All of them accept `lasting` and `feeling`. A popped-out or slid-out widget
  stops receiving clicks until something pops it back in.
- These also work as timeline steps: `add pop in button "Go" lasting 0.4
  seconds to timeline "reveal"`.

## how it works (the honest version)

Each animated target becomes a slot in the motion engine. The compiler
writes two tiny C callbacks per slot -- one reads the variable, one writes
it -- and the engine calls them every frame. Because animation lives in the
engine (not in generated frame code), a `move` sentence keeps animating no
matter where it appeared: top level, a handler, an `if` inside a loop. It
runs until it is done, or until you `stop` it.

The engine is pure C with no graphics dependency (`lib/motionkit.c`); the
game kit renders particles and effects, and the app kit applies widget
motion. That is also why the test suite can step time by hand:

```
move dot.x toward 100 lasting 1 second feeling bouncy
advance 1 second
print dot.x                       # 100 -- tween landed exactly
```

`advance 1 second` fast-forwards the whole animation clock. It is meant for
tests (`tests/11-motion.dep`) and headless experiments; in a real program
the clock ticks itself 60 times a second.

## complete demo programs

- `examples/animation-showcase.dep` -- an interactive playground: five
  feelings on five lanes, a spring-follow ghost, particles, shake, flash,
  zoom, and a patrol timeline.
- `examples/animated-todo.dep` -- the todo app with pop-in rows, a shaking
  field, sliding panels and bumping buttons.
- `examples/menu-scene.dep` -- an animated main menu: a spring-drop title on
  a timeline, twinkling stars, a springy selector, and a zoom-and-fade
  scene transition.
