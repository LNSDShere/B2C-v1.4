#!/usr/bin/env python3
"""dec -- the DeadEnd compiler CLI.

  dec run file.dep      compile and run a DeadEnd program
  dec build file.dep    compile into a standalone executable
  dec studio            open DeadEnd Studio (the button IDE)
  dec test              run the built-in test suite
  dec tour              start the interactive language tour
  dec doctor            check that your toolchain is ready
  dec clean             remove cached builds
  dec version | help
"""
import os
import sys
import hashlib
import subprocess
import shutil
import platform
import time

VERSION = "1.4.0"

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
LIB = os.path.join(ROOT, "lib")
VENDOR_RAYLIB = os.path.join(ROOT, "vendor", "raylib")
sys.path.insert(0, SRC)


def cache_dir():
    if os.environ.get("DEP_CACHE"):
        base = os.environ["DEP_CACHE"]
    elif platform.system() == "Windows":
        base = os.path.join(os.environ.get("LOCALAPPDATA",
                           os.path.expanduser("~")), "dec-cache")
    else:
        base = os.path.expanduser("~/.cache/dec")
    d = os.path.join(base, "v" + VERSION)
    os.makedirs(d, exist_ok=True)
    return d


def find_compiler():
    cands = []
    if os.environ.get("CC"):
        cands.append(os.environ["CC"])
    if platform.system() == "Windows":
        # the compiler that ships in the DeadEnd installer
        bundled = os.path.join(ROOT, "tools", "mingw64", "bin", "gcc.exe")
        if os.path.isfile(bundled):
            cands.append(bundled)
    cands += ["gcc", "clang", "cc"]
    for cc in cands:
        if not cc:
            continue
        if os.path.isabs(cc) or ("\\" in cc) or ("/" in cc):
            if os.path.isfile(cc):
                return cc
        elif shutil.which(cc):
            return cc
    return None


def sysroot_args():
    """Sandbox/testing support: DEP_SYSROOT points at extra headers+libs."""
    sr = os.environ.get("DEP_SYSROOT")
    if not sr:
        return [], []
    inc = ["-I", os.path.join(sr, "usr", "include")]
    libdirs = [os.path.join(sr, "usr", "lib", "x86_64-linux-gnu"),
               os.path.join(sr, "usr", "lib64"), os.path.join(sr, "usr", "lib")]
    lib = []
    for d in libdirs:
        if os.path.isdir(d):
            lib += ["-L", d]
    return inc, lib


def raylib_dir():
    """Where a built libraylib.a lives (or will be built)."""
    env = os.environ.get("DEP_RAYLIB_BUILD")
    if env and os.path.isfile(os.path.join(env, "libraylib.a")):
        return env
    if platform.system() == "Windows":
        # prebuilt win64 raylib shipped by the DeadEnd installer
        bundled = os.path.join(ROOT, "tools", "raylib")
        if os.path.isfile(os.path.join(bundled, "libraylib.a")):
            return bundled
    return os.path.join(cache_dir(), "raylib")


def platform_link_libs(rl_dir):
    sysname = platform.system()
    if sysname == "Windows":
        return ["-lopengl32", "-lgdi32", "-lwinmm"]
    if sysname == "Darwin":
        return ["-framework", "OpenGL", "-framework", "Cocoa",
                "-framework", "IOKit", "-framework", "CoreAudio",
                "-framework", "CoreVideo"]
    libs = ["-lGL", "-lX11", "-lXrandr", "-lXi", "-lXcursor",
            "-lXinerama", "-lm", "-lpthread", "-ldl", "-lrt"]
    audio_file = os.path.join(rl_dir, "audio.txt")
    if os.path.isfile(audio_file):
        try:
            with open(audio_file) as f:
                if "DEP_AUDIO=1" in f.read():
                    libs.append("-lasound")
        except OSError:
            pass
    return libs


def build_raylib(quiet=False):
    rl_dir = raylib_dir()
    if os.path.isfile(os.path.join(rl_dir, "libraylib.a")):
        return rl_dir
    if not quiet:
        print("First time using a kit: building raylib (about a minute, "
              "only once)...")
    os.makedirs(rl_dir, exist_ok=True)
    inc, _ = sysroot_args()
    env = dict(os.environ)
    script = os.path.join(VENDOR_RAYLIB, "build_raylib.sh")
    cmd = ["sh", script, rl_dir]
    if os.environ.get("DEP_SYSROOT"):
        cmd.append(os.environ["DEP_SYSROOT"])
    r = subprocess.run(cmd, env=env,
                       capture_output=quiet, text=not quiet)
    if r.returncode != 0 or not os.path.isfile(os.path.join(rl_dir, "libraylib.a")):
        if quiet:
            sys.stderr.write(r.stderr or r.stdout or "")
        die("could not build raylib -- see the messages above. "
            "On Linux install: sudo apt install libgl1-mesa-dev libasound2-dev "
            "libxrandr-dev libxi-dev libxcursor-dev libxinerama-dev")
    if not quiet:
        print("raylib ready.")
    return rl_dir


def die(msg, code=1):
    sys.stderr.write(f"dec: {msg}\n")
    sys.exit(code)


def compile_program(path, want_kits, debug=False, show_c=False):
    """Parse+transpile+compile. Returns path to executable."""
    from dep_parse import DepError, parse
    from dep_emit import Compiler

    try:
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
    except OSError as e:
        die(f"cannot read {path}: {e}")

    try:
        ast = parse(src)
        comp = Compiler(ast)
        c_code = comp.compile()
    except DepError as e:
        die(f"{os.path.basename(path)}: error: {e}")

    kits = bool(comp.kit)

    if show_c:
        print(c_code)

    cc = find_compiler()
    if not cc:
        die("DeadEnd compiles programs to native code, so it needs a C "
            "compiler.\n"
            "  Linux:  sudo apt install build-essential\n"
            "  macOS:  xcode-select --install\n"
            "  Windows: install MinGW-w64 (see README.md)")

    # the cache key must include the runtime libs, not just the generated
    # C -- otherwise a fixed lib/*.c keeps serving stale binaries.
    fp = hashlib.sha1()
    for lib_src in ("dep_runtime.c", "motionkit.c", "gamekit.c", "appkit.c"):
        p = os.path.join(LIB, lib_src)
        if os.path.isfile(p):
            with open(p, "rb") as f:
                fp.update(hashlib.sha1(f.read()).digest())
    key = hashlib.sha1(
        (VERSION + c_code + fp.hexdigest() +
         ("debug" if debug else "")).encode()
    ).hexdigest()[:16]
    out_dir = os.path.join(cache_dir(), key)
    os.makedirs(out_dir, exist_ok=True)
    exe = os.path.join(out_dir, "program")
    if platform.system() == "Windows":
        exe += ".exe"
    c_path = os.path.join(out_dir, "program.c")

    force = os.environ.get("DEP_FORCE")
    if os.path.isfile(exe) and not force:
        return exe

    with open(c_path, "w", encoding="utf-8") as f:
        f.write(c_code)

    inc, lib = sysroot_args()
    cmd = [cc, "-O2" if not debug else "-O0", "-w",
           "-I", LIB, "-I", VENDOR_RAYLIB,
           *inc, *lib,
           "-o", exe, c_path,
           os.path.join(LIB, "dep_runtime.c"),
           os.path.join(LIB, "motionkit.c")]
    rl_dir = None
    if kits:
        rl_dir = build_raylib()
        cmd += [os.path.join(LIB, "gamekit.c"),
                os.path.join(LIB, "appkit.c"),
                "-I", VENDOR_RAYLIB,
                os.path.join(rl_dir, "libraylib.a")]
        cmd += platform_link_libs(rl_dir)
        if platform.system() == "Windows":
            cmd += ["-mwindows"]   # games open a window, not a console
    if platform.system() != "Windows":
        cmd += ["-lm"]

    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stderr)
        die("compilation failed -- this is a bug in dec, please report it "
            "with the code above")
    return exe


def cmd_run(args):
    if not args:
        die("usage: dec run file.dep")
    path = args[0]
    debug = "--debug" in args
    show_c = "--show-c" in args
    exe = compile_program(path, None, debug=debug, show_c=show_c)
    os.execv(exe, [exe])


def cmd_build(args):
    if not args:
        die("usage: dec build file.dep [-o name]")
    path = args[0]
    out = None
    if "-o" in args:
        out = args[args.index("-o") + 1]
    else:
        out = os.path.splitext(os.path.basename(path))[0]
        if platform.system() == "Windows":
            out += ".exe"
    debug = "--debug" in args
    exe = compile_program(path, None, debug=debug)
    shutil.copy2(exe, out)
    print(f"built {out}")


def cmd_test(args):
    tests_dir = os.path.join(ROOT, "tests")
    if not os.path.isdir(tests_dir):
        die("no tests directory found")
    files = sorted(f for f in os.listdir(tests_dir) if f.endswith(".dep"))
    passed = failed = skipped = 0
    for f in files:
        path = os.path.join(tests_dir, f)
        expected_path = path[:-4] + ".expected"
        # kit tests need a display; skip gracefully when headless
        try:
            with open(path, encoding="utf-8") as sf:
                src = sf.read()
        except OSError:
            continue
        if ("use game kit" in src or "use app kit" in src) and \
                not os.environ.get("DISPLAY"):
            skipped += 1
            print(f"  skip  {f} (needs a display)")
            continue
        try:
            with open(expected_path, encoding="utf-8") as ef:
                expected = ef.read()
        except OSError:
            expected = None
        try:
            exe = compile_program(path, None)
            r = subprocess.run([exe], capture_output=True, text=True,
                               timeout=60,
                               env={**os.environ, "DEP_FRAMES": "3"})
            actual = r.stdout
            if expected is not None:
                if actual == expected and r.returncode == 0:
                    passed += 1
                    print(f"  ok    {f}")
                else:
                    failed += 1
                    print(f"  FAIL  {f}")
                    if actual != expected:
                        import difflib
                        for line in difflib.unified_diff(
                                expected.splitlines(), actual.splitlines(),
                                "expected", "actual", lineterm=""):
                            print("        " + line)
            else:
                if r.returncode == 0:
                    passed += 1
                    print(f"  ok    {f}")
                else:
                    failed += 1
                    print(f"  FAIL  {f} (exit {r.returncode})")
                    sys.stderr.write(r.stderr)
        except Exception as e:
            failed += 1
            print(f"  FAIL  {f} ({e})")
    print(f"\n{passed} passed, {failed} failed, {skipped} skipped, {len(files)} total")
    sys.exit(1 if failed else 0)


def cmd_doctor(args):
    print(f"dec {VERSION} -- doctor")
    print(f"  python      : {platform.python_version()}  [{sys.executable}]")
    cc = find_compiler()
    print(f"  C compiler  : {cc or 'NOT FOUND'}")
    if cc:
        r = subprocess.run([cc, "--version"], capture_output=True, text=True)
        print("               " + (r.stdout.splitlines() or [""])[0])
    print(f"  package     : {ROOT}")
    print(f"  cache       : {cache_dir()}")
    rl = os.path.join(raylib_dir(), "libraylib.a")
    print(f"  raylib      : {'built' if os.path.isfile(rl) else 'not built yet (builds on first game/app)'}")
    # try compiling the hello world
    hello = os.path.join(cache_dir(), "doctor.dep")
    with open(hello, "w") as f:
        f.write('print "doctor: ' + VERSION + ' ok"\n')
    try:
        exe = compile_program(hello, None)
        r = subprocess.run([exe], capture_output=True, text=True, timeout=60)
        print(f"  smoke test  : {'PASS' if r.returncode == 0 else 'FAIL'}")
        if r.returncode != 0:
            sys.stderr.write(r.stderr)
    except SystemExit:
        print("  smoke test  : FAIL")
    print("\nAll good -- go make something.")


def cmd_clean(args):
    import glob
    d = cache_dir()
    for entry in glob.glob(os.path.join(d, "*")):
        shutil.rmtree(entry, ignore_errors=True)
    print(f"cleared {d}")


def cmd_tour(args):
    from dep_tour import run_tour
    run_tour(ROOT, lambda path: compile_program(path, None))


def cmd_studio(args):
    from studio import main as studio_main
    sys.exit(studio_main(args))


HELP = """dec -- the DeadEnd compiler, version {v}

usage:
  dec run file.dep            compile and run a program
  dec run file.dep --show-c   also print the generated C code
  dec build file.dep [-o n]   compile into a standalone executable
  dec studio                  open DeadEnd Studio (buttons, no terminal)
  dec test                    run the test suite that ships with DeadEnd
  dec tour                    an interactive tour of the whole language
  dec doctor                  check your toolchain
  dec clean                   clear cached builds
  dec version                 print the version

quick start:
  dec studio
""".format(v=VERSION)


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("help", "--help", "-h"):
        print(HELP)
        return
    if argv[0] in ("version", "--version", "-v"):
        print(f"dec {VERSION} -- DeadEnd compiler")
        return
    cmd = argv[0]
    rest = argv[1:]
    if cmd == "run":
        cmd_run(rest)
    elif cmd == "build":
        cmd_build(rest)
    elif cmd == "test":
        cmd_test(rest)
    elif cmd == "doctor":
        cmd_doctor(rest)
    elif cmd == "clean":
        cmd_clean(rest)
    elif cmd == "tour":
        cmd_tour(rest)
    elif cmd == "studio":
        cmd_studio(rest)
    else:
        # convenience: dec hello.dep == dec run hello.dep
        if cmd.endswith(".dep"):
            cmd_run(argv)
        else:
            die(f"unknown command '{cmd}'. try: dec help")


if __name__ == "__main__":
    main()
