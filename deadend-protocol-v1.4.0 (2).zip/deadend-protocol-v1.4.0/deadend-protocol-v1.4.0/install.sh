#!/bin/sh
# Adds the `dec` command to your PATH (Linux/macOS).
# After installing, open a new terminal and run: dec doctor
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
BIN="$HOME/.local/bin"
mkdir -p "$BIN"
ln -sf "$DIR/dec" "$BIN/dec"
case ":$PATH:" in
  *":$BIN:"*) ;;
  *) echo "NOTE: $BIN is not in your PATH." ;;
esac
echo "Installed. Try:  dec tour"
