# DeadEnd

**The programming language that reads like English and runs like C.**

```
DeadEnd                          C (what it becomes)
──────────────────────────      ──────────────────────────
set score to 0                   double score = 0;
repeat 1000000000 times          for (long i = 0; i < 1e9; i++)
  change score by 1                score = score + 1;
end
print score                       printf("%g\n", score);
```

DeadEnd is a small language with one big idea: **you should not have to choose
between a language you can read and a language that runs fast.** DeadEnd
programs are written in plain English sentences, and the `dec` compiler
translates them into clean C, which GCC/Clang compiles to a native executable.

### The benchmark (counting to one billion)

| Language       | Time    | vs DeadEnd |
|----------------|---------|------------|
| **DeadEnd**    | 0.56 s  | —          |
| C (gcc -O2)    | 0.56 s  | same       |
| Python 3       | 73 s    | 130x slower|

DeadEnd is not "close to" C speed on this benchmark — it is the same code,
because it is compiled to the same C. Numeric variables become plain C
doubles, loops become C `for` loops, and the optimizer treats them exactly
like handwritten C.

---

## Quick start

### Windows -- the one-file install

**Got this source zip?** Extract it anywhere, then double-click
**`install.bat`** -- it checks Python and the C compiler, tells you exactly
what is missing (with links), and puts DeadEnd Studio on your desktop.

(If you have the bigger **DeadEnd-Setup-1.4.0-x64.exe** bundle instead, run
that -- the steps below describe what it does.) Double-click it, press Next a few
times. That is the whole install. It puts everything in your own folder
(no admin rights needed):

- the DeadEnd compiler and its bundled C compiler (GCC)
- **DeadEnd Studio**, the button-driven editor
- a desktop shortcut
- `.dep` files open with a **double-click** -- like `.txt` files open in
  Notepad, `.dep` files open in DeadEnd Studio

After installing, double-click **DeadEnd Studio** on your desktop. Write
some English, press **Run**, press **Build .exe**, and you get a real
Windows executable you can send to friends. To remove DeadEnd, use
"Add or remove programs" like any other app.

### From source (any OS)

You need Python 3 (any version 3.8+) and a C compiler.

| OS      | Install                                                                 |
|---------|-------------------------------------------------------------------------|
| Linux   | `sudo apt install build-essential python3` (Debian/Ubuntu) or your distro's equivalent |
| macOS   | `xcode-select --install` (installs Clang)                               |
| Windows | Double-click **`install.bat`** in this folder (it guides you), or manually: install [MinGW-w64](https://winlibs.com/) (pick a build, unzip, add `bin` to PATH) and Python 3 from python.org |

Check everything at once:

```
./dec doctor
```

Then open **DeadEnd Studio** -- the editor where everything is a button.
Write code, press Run, press Build .exe, get a real Windows executable.
No terminal skills required (it opens in your browser, but it runs on
your own computer):

```
./dec studio
```

Prefer a terminal? Take the tour -- 14 lessons, ~20 minutes, it teaches the
entire language (including animation) and runs real programs (including a
game and an app) as it goes:

```
./dec tour
```

Write your first program:

```
# hello.dep
print "Hello, world!"
```

```
./dec run hello.dep        # compile and run
./dec build hello.dep      # make a standalone executable called "hello"
```

Programs that use the game or app kit compile raylib the first time
(about a minute, once ever — it's cached).

---

## The whole language in one screen

```
# values
set name to "Ada"
set age to 36
set paid to yes
set tags to ["fast", "simple"]
set hero to {name: "Ada", x: 100, y: 50}

# decisions
if age is more than 30
  print "thirty-something"
else if age is nothing
  print "unknown"
else
  print "young"
end
if paid then print "thanks!"

# repetition
repeat 3 times
  print "again"
end
repeat with i from 1 to 100 by 2
  print i
end
while age is more than 0
  change age by -1
end
for each tag in tags
  print tag
end

# functions
function greet with name and excited
  set message to "Hello, " + name
  if excited
    set message to upper message + "!"
  end
  return message
end
print greet("Ada", yes)
```

Blocks end with the word `end`. Positions start at 1. Only `no`, `nothing`,
`0` and `""` count as false. There is nothing else to memorize — the full
reference is in [`docs/language.md`](docs/language.md).

---

## The built-in kits

### 2D Game Kit

```
use game kit

make game "Dot Chase" with width 400 and height 300

set dot to {x: 200, y: 150, w: 16, h: 16}

every frame
  if holding "left" then change dot.x by -4
  if holding "right" then change dot.x by 4
  if dot hits {x: 40, y: 40, w: 20, h: 20}
    print "collision!"
  end
  clear "night blue"
  circle dot.x, dot.y, 8, "gold"
  write "Score: 10", 10, 10, 20, "white"
  if pressed "escape"
    exit
  end
end

run game
```

Windows, 60fps loop, keyboard + mouse, circles/boxes/lines/text/images,
AABB collisions with `hits`, sound effects and music. Full reference:
[`docs/game-kit.md`](docs/game-kit.md). Complete game: [`examples/pong.dep`](examples/pong.dep).
Want to build one yourself? [`docs/flappy-bird.md`](docs/flappy-bird.md) builds
Flappy Bird step by step — finished game in [`examples/flappy.dep`](examples/flappy.dep).

### App Kit

```
use app kit

make window "Greeter" with width 340 and height 220

add title "Say hello" at 16, 14
add field "who" at 16, 60 with width 200
add button "Greet" at 16, 96
add label "out" at 16, 150

when button "Greet" is clicked
  set label "out" to "Hello, " + field "who" + "!"
end

run app
```

Real desktop apps with buttons, text fields, checkboxes, sliders, labels,
images and panels. Full reference: [`docs/app-kit.md`](docs/app-kit.md).
Complete app: [`examples/todo.dep`](examples/todo.dep) (it even saves your list to disk).

### Motion Kit (new in 1.4.0)

Animation in plain English -- for games **and** apps. Tween anything with
`move`, animate with real physics using `spring`, chain steps into named
timelines, and dress it all up with particles and screen effects:

```
use game kit

make game "Orbit" with width 400 and height 300

set dot to {x: 50, y: 150}

when game starts
  fade from black lasting 1 second
  make timeline "intro"
  add move dot toward {x: 350, y: 150} lasting 1.5 seconds feeling bouncy to timeline "intro"
  add move dot toward {x: 50, y: 150} lasting 1.5 seconds feeling springy to timeline "intro"
  play timeline "intro" repeating forever
end

every frame
  clear "night blue"
  circle dot.x, dot.y, 14, "gold"
  if pressed "space"
    burst 30 sparks at dot.x, dot.y with color "gold" and speed 180
    shake screen with strength 6 lasting 0.25 seconds
    flash white lasting 0.1 seconds
  end
end

run game
```

31 easing curves behind feeling words like `bouncy`, `snappy`, `springy`,
`smooth`, `quick` -- or name one directly: `feeling "ease-out-bounce"`.
Springs take `with speed 2` (how fast) and `with wobble 6` (how much it
oscillates), or raw `with stiffness 300 and damping 12` when you want full
control. Timelines chain `move`/`spring`/`wait`/widget steps and run them
one after another; ask `moving dot.x`, `playing "intro"`, `finished "intro"`.
In apps: `pop in button "Go"`, `slide out panel "menu" to "left"`,
`glide label "coin" to 300, 200`, `bump button "Go"`, `shake field "name"`.
Full reference: [`docs/animation-kit.md`](docs/animation-kit.md).
Demos: [`examples/animation-showcase.dep`](examples/animation-showcase.dep),
[`examples/animated-todo.dep`](examples/animated-todo.dep),
[`examples/menu-scene.dep`](examples/menu-scene.dep).

---

## What's in the box

```
dec                 the compiler command (run/build/test/tour/doctor/clean)
src/                the compiler itself (Python, ~3000 lines, no dependencies)
lib/                the DeadEnd runtime + game kit + app kit + motion kit (C)
vendor/raylib/      raylib 5.5 source (the graphics engine behind both kits)
examples/           pong, flappy bird, a todo app, three animation demos, benchmark, and more
tests/              the test suite -- run it yourself: dec test
docs/               language + kit reference (start with animation-kit.md)
```

## Commands

```
dec run file.dep          compile and run a program
dec run file.dep --show-c also print the generated C (see for yourself!)
dec build file.dep [-o n] compile into a standalone executable
dec test                  run the test suite that ships with DeadEnd
dec tour                  interactive tour of the whole language
dec doctor                check your toolchain
dec clean                 clear cached builds
```

## Honest notes

* Memory is reference counted. Cycles (a list that contains itself) are not
  collected — they are freed when the program exits. In practice this never
  comes up in normal programs.
* One kit per program for now (game kit or app kit).
* Generated C uses GCC/Clang statement expressions, so MSVC is not supported —
  use MinGW-w64 on Windows.
* DeadEnd is single-threaded by design.

## Why "DeadEnd"?

The language is named after the [Dead-End Protocol](https://github.com/LNSDShere/dead-end-protocol-prototype):
*never mistake a failed method for an impossible task.* A failed method
proves the method wrong — the task stays open. Every language that told you
speed and simplicity was a trade-off was reporting the failure surface of its
method, not a law of nature.

License: MIT (see [LICENSE](LICENSE)). Ships with raylib 5.5 (zlib) — see
[THIRD_PARTY.md](THIRD_PARTY.md).
